#include "BattleShip.h"

int main()
{
	//Variable Types Used
	//Pseudo random number used
	int thisPlayer = rand() % 2;
	//pointer initialized
	//Dynamic memory created
	Battleship *battleS = new Battleship();

	for (int atotalPlayers = 1; atotalPlayers<3; ++atotalPlayers)
	{
		for (int thisShip = 0; thisShip<battleS->getShipsCount(); ++thisShip)
		{
			battleS->makeBoard(atotalPlayers);
			cout << "\n";
			if (atotalPlayers == 1)
				cout << "Player " << atotalPlayers << "\n";
			else
				cout << "Computer \n";
			cout << "Ship Name: " << ship[thisShip].nameOfShip << " Ship Size " << ship[thisShip].shipLength << "\n";

			PLACESHIPS aShip;
			aShip.selectedShip.gridPoint[0].pointXAxis = -1;
			while (aShip.selectedShip.gridPoint[0].pointXAxis == -1)
			{
				//Pointer dereferenced
				//References added

				aShip = battleS->shipAxis(atotalPlayers);
			}

			aShip.selectedShip.shipLength = ship[thisShip].shipLength;
			aShip.selectedShip.nameOfShip = ship[thisShip].nameOfShip;

			player[atotalPlayers].gridMark[aShip.selectedShip.gridPoint[0].pointXAxis][aShip.selectedShip.gridPoint[0].pointYAxis] = battleS->wrongShip;
			//Relational Operator used
			//iteration structures loop used
			for (int i = 1; i<aShip.selectedShip.shipLength; ++i)
			{
				//Logical Operator used
				if (aShip.axisXY == HORIZONTAL) {
					aShip.selectedShip.gridPoint[i].pointXAxis = aShip.selectedShip.gridPoint[i - 1].pointXAxis + 1;
					aShip.selectedShip.gridPoint[i].pointYAxis = aShip.selectedShip.gridPoint[i - 1].pointYAxis;
				}
				//conditional statement used
				if (aShip.axisXY == VERTICAL) {
					//Arithmetic Operator used
					aShip.selectedShip.gridPoint[i].pointYAxis = aShip.selectedShip.gridPoint[i - 1].pointYAxis + 1;
					aShip.selectedShip.gridPoint[i].pointXAxis = aShip.selectedShip.gridPoint[i - 1].pointXAxis;
				}

				player[atotalPlayers].gridMark[aShip.selectedShip.gridPoint[i].pointXAxis][aShip.selectedShip.gridPoint[i].pointYAxis] = battleS->wrongShip;
			}
		}
	}

	untilRunningGame = true;

	do {
		int enemyPlayer;
		if (thisPlayer == 1) enemyPlayer = 2;
		if (thisPlayer == 2) enemyPlayer = 1;
		battleS->makeBoard(enemyPlayer);

		bool inputtedPlayer = false;
		int xPnt, yPnt;
		while (inputtedPlayer == false) {
			inputtedPlayer = battleS->inputAxis(xPnt, yPnt, thisPlayer);
		}

		if (player[enemyPlayer].gridMark[xPnt][yPnt] == battleS->wrongShip) player[enemyPlayer].gridMark[xPnt][yPnt] = battleS->rightMark;
		if (player[enemyPlayer].gridMark[xPnt][yPnt] == battleS->waterPlace) player[enemyPlayer].gridMark[xPnt][yPnt] = battleS->wrongMark;

		int aWin = battleS->GameEnd(enemyPlayer);
		if (aWin != 0) {
			untilRunningGame = false;
			break;
		}
		thisPlayer = (thisPlayer == 1) ? 2 : 1;
	} while (untilRunningGame);

	cout << "\nPLAYER " << thisPlayer << " HAS WON \n";

	system("pause");
	return 0;
}