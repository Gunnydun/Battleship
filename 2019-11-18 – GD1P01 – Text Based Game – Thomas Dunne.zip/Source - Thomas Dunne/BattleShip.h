#ifndef BATTLESHIP_H
#define BATTLESHIP_H
#include <iostream>
#include <string>
using namespace std;

//constants used
const int gridSize = 5;
const int boardSizeWH = 10;

bool untilRunningGame;

struct POINT {
	int pointXAxis;
	int pointYAxis;
};

struct SHIP {
	string nameOfShip;
	int shipLength;
	POINT gridPoint[gridSize];
	bool flagIfRightHit[gridSize];
}ship[5];

//Objects declared
struct PLAYER {
	//Arrays used
	char gridMark[boardSizeWH][boardSizeWH];
}player[3];

enum axisDirec { HORIZONTAL, VERTICAL };
struct PLACESHIPS {
	axisDirec axisXY;
	SHIP selectedShip;
};

//Class Used
class Battleship
{
	//access modifier private used
private:
	int matrixW;
	int matrixH;
	int shipsCount;
	//access modifier public used
public:

	char waterPlace = '.';
	char rightMark = 'X';
	char wrongShip = 'S';
	char wrongMark = '0';
	//default parameters used
	//Constructor declared
	Battleship(int w=10, int h=10)
	{
		this->matrixW = w;
		this->matrixH = h;
		this->shipsCount = 5;
		untilRunningGame = false;

		ship[0].nameOfShip = "Aircraft Carrier"; ship[0].shipLength = 5;
		ship[1].nameOfShip = "Battleship"; ship[1].shipLength = 4;
		ship[2].nameOfShip = "Destroyer"; ship[2].shipLength = 3;
		ship[3].nameOfShip = "Submarine"; ship[3].shipLength = 3;
		ship[4].nameOfShip = "Patrol Boat"; ship[4].shipLength = 2;

		for (int totalPlayers = 1; totalPlayers<3; ++totalPlayers)
		{
			for (int w = 0; w<matrixW; ++w) {
				for (int h = 0; h<matrixH; ++h) {
					player[totalPlayers].gridMark[w][h] = waterPlace;
				}
			}
		}

	}
	//Copy Constructor used
	Battleship(const Battleship &battle)
	{
		this->matrixH = battle.matrixH;
		this->matrixW = battle.matrixW;
		this->shipsCount = battle.shipsCount;
	}
	//Destructor used
	~Battleship()
	{
		
		for (int totalPlayers = 1; totalPlayers<3; ++totalPlayers)
		{
			for (int w = 0; w<matrixW; ++w) {
				for (int h = 0; h<matrixH; ++h) {
					player[totalPlayers].gridMark[w][h] = waterPlace;
				}
			}
		}

		untilRunningGame = false;
	}

	bool GameEnd(int enemyPLAYER)
	{
		bool winPlayer = true;
		for (int w = 0; w<matrixW; ++w) {
			for (int h = 0; h<matrixH; ++h) {
				if (player[enemyPLAYER].gridMark[w][h] = wrongShip)
				{
					winPlayer = false;
					return winPlayer;
				}
			}
		}
		return winPlayer;
	}


	bool inputAxis(int& xPnt, int& yPnt, int selectedPlayer)
	{
		if (selectedPlayer == 1)
		{
			cout << ", Enter x y to attack: ";
			cin >> xPnt >> yPnt;
		}
		else
		{
			xPnt = rand() % 10;
			yPnt = rand() % 10;
			cout << " Computer Entered X,Y : " << xPnt << " , " << yPnt << endl;
		}
		if (xPnt<0 || xPnt >= matrixW) return false;
		if (yPnt<0 || yPnt >= matrixH) return false;
		return true;
	}

	PLACESHIPS shipAxis(int selectedPlayer)
	{
		int d, xPnt, yPnt;
		PLACESHIPS tmp;
		tmp.selectedShip.gridPoint[0].pointXAxis = -1;
		if (selectedPlayer == 1)
		{
			cout << "Enter Coordinates as ( 0/1(horizontal or vertical) 1(x axis) 1(y axis) ) e.g 0 1 1 : ";
			cin >> d >> xPnt >> yPnt;
		}
		else
		{
			
			d = rand() % 2;
			xPnt = rand() % 10;
			yPnt = rand() % 10;
			cout << "Computer Entered Coordinates : " << d << " " << xPnt << " " << yPnt << endl;
		}
		if (d != 0 && d != 1) return tmp;
		if (xPnt<0 || xPnt >= matrixW) return tmp;
		if (yPnt<0 || yPnt >= matrixH) return tmp;
		tmp.axisXY = (axisDirec)d;
		tmp.selectedShip.gridPoint[0].pointXAxis = xPnt;
		tmp.selectedShip.gridPoint[0].pointYAxis = yPnt;
		return tmp;
	}

	void makeBoard(int thisPlayer)
	{
		if (thisPlayer == 1)
			cout << "PLAYER " << thisPlayer << "\n";
		else
			cout << "COMPUTER \n";
		cout << "----------------------\n";
		cout << "   ";
		for (int w = 0; w<matrixW; ++w) {
			if (w < 10)
				cout << w << "  ";
			else if (w >= 10)
				cout << w << " ";
		}
		cout << "\n";

		for (int h = 0; h<matrixH; ++h) {
			for (int w = 0; w<matrixW; ++w) {
				if (w == 0) cout << h << " ";
				if (w<10 && w == 0) cout << " ";
				if (untilRunningGame == false) cout << player[thisPlayer].gridMark[w][h] << "  ";
				if (untilRunningGame == true && player[thisPlayer].gridMark[w][h] != wrongShip)
				{
					cout << player[thisPlayer].gridMark[w][h] << "  ";
				}
				else if (untilRunningGame == true && player[thisPlayer].gridMark[w][h] == wrongShip)
				{
					cout << waterPlace << "  ";
				}
				if (w == matrixW - 1) cout << "\n";
			}
		}
	}

	int getShipsCount()
	{
		return this->shipsCount;
	}
};

#endif